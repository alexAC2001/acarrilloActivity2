<h1>Login Passed</h1>

<?php if($model->getUsername()=='mark'): ?>
	<h3>Mark you have logged in successfully.</h3>
<?php else: ?>
	<h3>Someone besides mark logged in successfully.</h3>
<?php endif; ?><?php /**PATH C:\MAMP\htdocs\Act2b\resources\views/loginPassed2.blade.php ENDPATH**/ ?>