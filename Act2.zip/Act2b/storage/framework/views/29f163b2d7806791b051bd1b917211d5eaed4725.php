<html land="en">
	<head>
		<title>Welcome</title>	
	</head>
	<body>
		<div align="center">
			Welcomme to Activity 2
		</div>
	</body>
</html><?php /**PATH C:\MAMP\htdocs\Act2b\resources\views/layouts/header.blade.php ENDPATH**/ ?>