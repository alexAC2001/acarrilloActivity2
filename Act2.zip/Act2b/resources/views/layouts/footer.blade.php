<html land="en">
	<head>
		<title>Welcome</title>	
	</head>
	<body>
		<div align="center">
			<h5>Copyright @2018 My Own Company Name</h5>
		</div>
	</body>
</html>