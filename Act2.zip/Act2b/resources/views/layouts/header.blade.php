<html land="en">
	<head>
		<title>Welcome</title>	
	</head>
	<body>
		<div align="center">
			Welcomme to Activity 2
		</div>
	</body>
</html>