<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/askme', function() {return view('whoami');});
// PART 1:
Route::get('/whoami', 'WhatsMyNameController@index');



// Route that will fire when we type in 'login' in the url
// This is just the name people will see on the outside
// as they type in the url.
Route::get('/login', function()
{
  echo("This is a test");
  // View 'loginView' has to be the name of the file in the views.
  return view('loginView');
});

// When the data is posted from the login page with 
// action set to 'dologin' it will come here.
// Then it will route the request to a function called index
// in the LoginController
Route::post('/dologin', 'LoginController@index');

Route::get('/login2', function()
{
    return view('login2');
});
